import java.io.*;
import java.util.Scanner;

public class Object {
    public static void getCategory() {
        Admin.letGetCategory();
    }

    public static void getSubCategory(String category) {
        Admin.letGetSubCategory(category);
    }

    public static void getProducts(String subCategory) {
        Admin.letGetProducts(subCategory);
    }

    public static void main(String[] args) {

    }
}